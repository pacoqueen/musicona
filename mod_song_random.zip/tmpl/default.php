<?php defined('_JEXEC') or die('Restricted access'); // no direct access ?>
<a href="<?php echo 'images/songs/' . $item->mp3; ?>" ><?php echo $item->name; ?></a>
<?php print $item->plugin_code; ?>


